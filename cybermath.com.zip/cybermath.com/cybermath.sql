-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2025 at 02:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cybermath`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'Admin@ee.ee', 'Admin@ee.ee', '$2y$10$RYO5qDSlPPHi8aFdz1A9feysrfU0.Gsys3p/LqF9PD0Gk4DIX1wOm', '2025-04-29 10:05:52');

-- --------------------------------------------------------

--
-- Table structure for table `moderator`
--

CREATE TABLE `moderator` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `moderator_requests`
--

CREATE TABLE `moderator_requests` (
  `id` int(11) NOT NULL,
  `moderator_id` int(11) NOT NULL,
  `target_name` varchar(255) NOT NULL,
  `action` enum('give_coins','block_user','delete_user') NOT NULL,
  `coins` int(11) DEFAULT 0,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `coins` int(11) DEFAULT 0,
  `status` enum('active','blocked') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `coins`, `status`) VALUES
(1, 'CyberMath0', 'sofia.anna.jakobson@ivkhk.ee', '$2y$10$7usPUDEmhSgDNtQ8w5EsYulNe.7D8uBG284LEhoW6PHm0c3fw66B6', '2025-04-29 09:30:39', 100, 'active'),
(2, 'CyberMath1', 'gaabriel.zachar@ivkhk.ee', '$2y$10$f9TCS7RxhS.f7A4Nw6EZeuZDafgz/Xj3HYPqcbSaDkcBlkjvGw986', '2025-04-29 11:22:53', 100, 'active'),
(3, 'CyberMath2', 'gaabriel.zachar@ovkhk.ee', '$2y$10$Oo19wRNVdLiMdRbH4cv8x.vzSGabOVcKj0ZMse/r/kIxDWgxWYeN6', '2025-04-29 11:32:27', 100, 'active'),
(4, 'CyberMath3', 'adadadadada@ee.ee', '$2y$10$z3VswOG80aEPMa8I1HDqiOZk3UNc/3hKOLLANqPgtULMsis9URh3W', '2025-04-29 11:40:57', 100, 'active'),
(5, 'CyberMath4', 'adadadad22ada@ee.ee', '$2y$10$S2c0bSwEi276a3Z/u3iuLOKorFc5lmy07Xbo9CnhJjezS/kIklOgi', '2025-04-29 11:43:01', 100, 'active'),
(6, 'CyberMath5', 'adadadadada4444@ee.ee', '$2y$10$HwV.u94CsAcdIlVHTmrpseo0.vNUsclaHXnNygMmI3pbjn034g9r.', '2025-04-29 11:48:30', 100, 'active'),
(7, 'CyberMath6', 'ni22@gmail.com', '$2y$10$TpEOnXSnIvO741CzuX4Ri.DNCRLh6d1jswakpOq3Cza3NORAcHbG2', '2025-04-29 11:52:54', 100, 'active'),
(8, 'CyberMath7', 'gaabriel.zachar222@ivkhk.ee', '$2y$10$FTcpMZobQqK5tkksgsowyeGX/m5A30Cgt3pC/9X5RTmvlz3I7NG1O', '2025-04-29 11:58:17', 50, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `user_topics`
--

CREATE TABLE `user_topics` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `completed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_topics`
--

INSERT INTO `user_topics` (`id`, `user_id`, `topic_id`, `completed_at`) VALUES
(1, 1, 1, '2025-04-29 09:58:01'),
(2, 1, 2, '2025-04-29 11:16:11'),
(3, 2, 1, '2025-04-29 11:23:18'),
(4, 3, 1, '2025-04-29 11:33:31'),
(5, 4, 1, '2025-04-29 11:41:31'),
(6, 5, 1, '2025-04-29 11:45:57'),
(7, 6, 1, '2025-04-29 11:48:56'),
(8, 7, 1, '2025-04-29 11:53:19'),
(9, 8, 1, '2025-04-29 11:58:44');

--
-- Triggers `user_topics`
--
DELIMITER $$
CREATE TRIGGER `add_coins_after_topic_completed` AFTER INSERT ON `user_topics` FOR EACH ROW BEGIN
    -- Добавляем 50 монет пользователю после того, как он завершает тему
    UPDATE users
    SET coins = coins + 50
    WHERE id = NEW.user_id;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `moderator`
--
ALTER TABLE `moderator`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `moderator_requests`
--
ALTER TABLE `moderator_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `user_topics`
--
ALTER TABLE `user_topics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`topic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `moderator`
--
ALTER TABLE `moderator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `moderator_requests`
--
ALTER TABLE `moderator_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_topics`
--
ALTER TABLE `user_topics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
