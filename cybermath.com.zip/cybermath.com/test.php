<?php
require_once __DIR__ . '/vendor/autoload.php';

echo "Google API Client установлен и подключен!";
