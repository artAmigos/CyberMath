# CyberMath
CyberMath_Developers
composer require vlucas/phpdotenv

ru, languages

add file .env 
DB_HOST=localhost
DB_NAME=apparta
DB_USER=root
DB_PASS=

